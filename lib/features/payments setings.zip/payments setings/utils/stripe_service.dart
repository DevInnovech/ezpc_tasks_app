// stripe_service.dart
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:stripe_payment/stripe_payment.dart';

class StripeService {
  static final StripeService instance = StripeService._internal();

  final String _publishableKey = "your-publishable-key";
  final String _secretKey = "your-secret-key";
  final String _baseUrl = "https://api.stripe.com/v1";

  StripeService._internal();

  // Initialize Stripe with publishable key
  void initialize(String publishableKey) {
    StripePayment.setOptions(
      StripeOptions(
        publishableKey: publishableKey,
        merchantId: "Test", // Merchant ID for Apple Pay/Google Pay
        androidPayMode: 'test', // Switch to "production" in production
      ),
    );
  }

  Future<Map<String, dynamic>> createPaymentIntent(
      String amount, String currency) async {
    final url = Uri.parse("$_baseUrl/payment_intents");
    final headers = {
      "Authorization": "Bearer $_secretKey",
      "Content-Type": "application/x-www-form-urlencoded",
    };
    final body = {
      "amount": amount,
      "currency": currency,
      "payment_method_types[]": "card",
    };

    try {
      final response = await http.post(url, headers: headers, body: body);
      if (response.statusCode == 200) {
        return {
          "success": true,
          "data": jsonDecode(response.body),
        };
      } else {
        return {
          "success": false,
          "error": jsonDecode(response.body),
        };
      }
    } catch (e) {
      return {
        "success": false,
        "error": e.toString(),
      };
    }
  }

  Future<void> confirmPayment(
      String clientSecret, String paymentMethodId) async {
    final url = Uri.parse("$_baseUrl/payment_intents/$clientSecret/confirm");
    final headers = {
      "Authorization": "Bearer $_secretKey",
      "Content-Type": "application/x-www-form-urlencoded",
    };
    final body = {
      "payment_method": paymentMethodId,
    };

    try {
      final response = await http.post(url, headers: headers, body: body);
      if (response.statusCode != 200) {
        throw Exception("Failed to confirm PaymentIntent: ${response.body}");
      }
    } catch (e) {
      throw Exception("Failed to confirm PaymentIntent: $e");
    }
  }

  Future<Map<String, dynamic>> addCard({
    required String cardNumber,
    required String expMonth,
    required String expYear,
    required String cvc,
  }) async {
    final card = CreditCard(
      number: cardNumber,
      expMonth: int.parse(expMonth),
      expYear: int.parse(expYear),
      cvc: cvc,
    );

    try {
      final token = await StripePayment.createTokenWithCard(card);
      return {
        "success": true,
        "token": token.tokenId,
      };
    } catch (e) {
      return {
        "success": false,
        "error": e.toString(),
      };
    }
  }

  Future<Map<String, dynamic>> deleteCard(String cardId) async {
    try {
      // Simulate backend call to delete the card
      return {
        "success": true,
        "message": "Card deleted successfully",
      };
    } catch (e) {
      return {
        "success": false,
        "error": e.toString(),
      };
    }
  }

  Future<Map<String, dynamic>> addBankAccount({
    required String accountHolderName,
    required String accountNumber,
    required String routingNumber,
    required String bankName,
  }) async {
    try {
      // Backend must handle integration with Stripe to add bank accounts
      return {
        "success": true,
        "message": "Bank account added successfully",
      };
    } catch (e) {
      return {
        "success": false,
        "error": e.toString(),
      };
    }
  }

  Future<Map<String, dynamic>> deleteBankAccount(String bankAccountId) async {
    try {
      // Simulate backend call to delete the bank account
      return {
        "success": true,
        "message": "Bank account deleted successfully",
      };
    } catch (e) {
      return {
        "success": false,
        "error": e.toString(),
      };
    }
  }
}
