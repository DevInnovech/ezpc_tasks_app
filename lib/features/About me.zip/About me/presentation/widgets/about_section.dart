import 'package:flutter/material.dart';

class AboutSection extends StatefulWidget {
  final String descripcion;

  const AboutSection({Key? key, required this.descripcion}) : super(key: key);

  @override
  _AboutSectionState createState() => _AboutSectionState();
}

class _AboutSectionState extends State<AboutSection> {
  bool isExpanded = false;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "About Tasks",
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        Text(
          isExpanded
              ? widget.descripcion
              : "${widget.descripcion.substring(0, 50)}...",
          textAlign: TextAlign.left,
        ),
        TextButton(
          onPressed: () {
            setState(() {
              isExpanded = !isExpanded;
            });
          },
          child: Text(isExpanded ? "Read less" : "Read more"),
        ),
      ],
    );
  }
}
