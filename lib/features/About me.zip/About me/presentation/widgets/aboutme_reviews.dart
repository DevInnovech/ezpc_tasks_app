import 'package:ezpc_tasks_app/features/About%20me/models/review_model.dart';
import 'package:flutter/material.dart';

class AboutMeReviews extends StatelessWidget {
  final List<ReviewModel> reviews;

  const AboutMeReviews({Key? key, required this.reviews}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      itemCount: reviews.length,
      itemBuilder: (context, index) {
        final review = reviews[index];
        return ListTile(
          leading: CircleAvatar(
            backgroundImage: NetworkImage(review.imagen),
          ),
          title: Text(review.userName),
          subtitle: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(review.comment),
              Row(
                children: List.generate(
                  5,
                  (i) => Icon(
                    Icons.star,
                    color: i < review.rating ? Colors.amber : Colors.grey,
                    size: 16,
                  ),
                ),
              ),
            ],
          ),
          trailing: Text(
            review.date.toString(),
            style: const TextStyle(color: Colors.grey),
          ),
        );
      },
    );
  }
}
