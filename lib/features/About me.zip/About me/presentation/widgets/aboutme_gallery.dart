import 'package:flutter/material.dart';

class AboutMeGallery extends StatelessWidget {
  final List<String> images;

  const AboutMeGallery({Key? key, required this.images}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: GridView.builder(
        shrinkWrap: true,
        physics: NeverScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          mainAxisSpacing: 4,
          crossAxisSpacing: 4,
        ),
        itemCount: images.length,
        itemBuilder: (context, index) {
          return GestureDetector(
            onTap: () {
              // Lógica para ver la imagen en tamaño completo
            },
            child: Image.network(images[index], fit: BoxFit.cover),
          );
        },
      ),
    );
  }
}
