import 'package:ezpc_tasks_app/features/About%20me/models/AboutMeModel.dart';
import 'package:flutter/material.dart';

class AboutMeHeader extends StatelessWidget {
  final AboutMeModel aboutMe;

  const AboutMeHeader({Key? key, required this.aboutMe}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // Fondo principal de la imagen
        Container(
          height: 200,
          decoration: BoxDecoration(
            image: DecorationImage(
              image: NetworkImage(aboutMe.imagen),
              fit: BoxFit.cover,
            ),
          ),
        ),
        // Información del proveedor
        Positioned(
          bottom: 10,
          left: 20,
          right: 20,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                aboutMe.name,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                aboutMe.description,
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: Colors.white),
              ),
              Row(
                children: [
                  IconButton(
                    icon: Icon(Icons.message, color: Colors.white),
                    onPressed: () {
                      // Lógica para el botón de mensaje
                    },
                  ),
                  IconButton(
                    icon: Icon(Icons.phone, color: Colors.white),
                    onPressed: () {
                      // Lógica para el botón de llamada
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}
