import 'dart:io';
import 'package:ezpc_tasks_app/features/About%20me/data/aboutme_provider.dart';
import 'package:ezpc_tasks_app/features/About%20me/models/AboutMeModel.dart';
import 'package:ezpc_tasks_app/shared/widgets/primary_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';

class EditAboutMeScreen extends ConsumerStatefulWidget {
  const EditAboutMeScreen({Key? key}) : super(key: key);

  @override
  _EditAboutMeScreenState createState() => _EditAboutMeScreenState();
}

class _EditAboutMeScreenState extends ConsumerState<EditAboutMeScreen> {
  late TextEditingController nameController;
  late TextEditingController descriptionController;
  late TextEditingController locationController;
  late TextEditingController contactController;
  File? _imageFile;

  @override
  void initState() {
    super.initState();

    // Verificar si hay datos disponibles
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final profileAsync = ref.read(aboutMeProvider);
      profileAsync.when(
        data: (profile) {
          setState(() {
            nameController = TextEditingController(text: profile.name);
            descriptionController =
                TextEditingController(text: profile.description);
            locationController = TextEditingController(text: profile.location);
            contactController =
                TextEditingController(text: profile.contactNumber);
          });
        },
        loading: () {
          // Opcional: Mostrar un indicador de carga aquí
        },
        error: (err, stack) {
          // Opcional: Manejo de errores aquí
        },
      );
    });
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        _imageFile = File(pickedFile.path);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final profileAsync = ref.watch(aboutMeProvider);

    return Scaffold(
      appBar: AppBar(title: const Text("Edit Profile")),
      body: profileAsync.when(
        data: (profile) => Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              // Imagen de perfil
              GestureDetector(
                onTap: _pickImage,
                child: CircleAvatar(
                  radius: 50,
                  backgroundImage: _imageFile != null
                      ? FileImage(_imageFile!)
                      : NetworkImage(profile.imagen) as ImageProvider,
                  child: _imageFile == null
                      ? const Icon(Icons.camera_alt,
                          size: 30, color: Colors.white)
                      : null,
                ),
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: nameController,
                decoration: const InputDecoration(labelText: "Name"),
              ),
              TextFormField(
                controller: descriptionController,
                decoration: const InputDecoration(labelText: "Description"),
              ),
              TextFormField(
                controller: locationController,
                decoration: const InputDecoration(labelText: "Location"),
              ),
              TextFormField(
                controller: contactController,
                decoration: const InputDecoration(labelText: "Contact Number"),
              ),
              const SizedBox(height: 20),
              PrimaryButton(
                text: "Save",
                onPressed: () {
                  final updatedProfile = profile.copyWith(
                    name: nameController.text,
                    description: descriptionController.text,
                    location: locationController.text,
                    contactNumber: contactController.text,
                    imagen: _imageFile?.path ?? profile.imagen,
                  );
                  ref
                      .read(aboutMeEditProvider.notifier)
                      .updateProfile(updatedProfile);
                  Navigator.pop(context);
                },
              ),
            ],
          ),
        ),
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (error, _) => Center(
          child: Text("Error: $error"),
        ),
      ),
    );
  }

  @override
  void dispose() {
    nameController.dispose();
    descriptionController.dispose();
    locationController.dispose();
    contactController.dispose();
    super.dispose();
  }
}
