import 'package:ezpc_tasks_app/features/About%20me/data/aboutme_provider.dart';
import 'package:ezpc_tasks_app/features/About%20me/presentation/widgets/aboutme_gallery.dart';
import 'package:ezpc_tasks_app/features/About%20me/presentation/widgets/aboutme_header.dart';
import 'package:ezpc_tasks_app/features/About%20me/presentation/widgets/aboutme_reviews.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class PreviewAboutMeScreen extends ConsumerWidget {
  const PreviewAboutMeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final aboutMeData = ref.watch(aboutMeProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text("Preview Profile"),
        backgroundColor: Colors.blueAccent,
      ),
      body: aboutMeData.when(
        data: (aboutMe) => Column(
          children: [
            AboutMeHeader(aboutMe: aboutMe),
            const SizedBox(height: 20),
            AboutMeGallery(images: aboutMe.gallery),
            const SizedBox(height: 20),
            AboutMeReviews(reviews: aboutMe.reviews),
          ],
        ),
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text("Error: $e")),
      ),
    );
  }
}
