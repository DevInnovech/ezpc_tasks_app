import 'package:ezpc_tasks_app/features/About%20me/data/aboutme_provider.dart';
import 'package:ezpc_tasks_app/features/About%20me/presentation/widgets/aboutme_gallery.dart';
import 'package:ezpc_tasks_app/features/About%20me/presentation/widgets/aboutme_header.dart';
import 'package:ezpc_tasks_app/features/About%20me/presentation/widgets/aboutme_reviews.dart';
import 'package:ezpc_tasks_app/shared/widgets/primary_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class AboutMeScreen extends ConsumerWidget {
  const AboutMeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final aboutMeData = ref.watch(aboutMeProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text("About Me"),
        backgroundColor: Colors.blueAccent,
      ),
      body: aboutMeData.when(
        data: (aboutMe) => Column(
          children: [
            AboutMeHeader(aboutMe: aboutMe),
            const SizedBox(height: 20),
            AboutMeGallery(images: aboutMe.gallery),
            const SizedBox(height: 20),
            AboutMeReviews(reviews: aboutMe.reviews),
          ],
        ),
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text("Error: $e")),
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(16.0),
        child: PrimaryButton(
          text: "Book Now",
          onPressed: () {
            // Acción de reservar
          },
        ),
      ),
    );
  }
}
