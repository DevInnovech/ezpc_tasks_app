import 'package:ezpc_tasks_app/features/About%20me/models/AboutMeModel.dart';
import 'package:ezpc_tasks_app/features/About%20me/models/review_model.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class AboutMeRepository {
  // Método para simular la obtención de datos del perfil del proveedor
  Future<AboutMeModel> getAboutMe() async {
    // Datos falsos para visualizar en el perfil
    return AboutMeModel(
      rating: 4,
      serviceType: '',
      imagen: '',
      name: 'Juan Perez',
      description:
          'Proveedor experimentado en servicios de construcción y remodelación.',
      location: 'Ciudad de México, MX',
      contactNumber: '+52 55 1234 5678',
      gallery: [
        'https://example.com/image1.jpg',
        'https://example.com/image2.jpg',
        'https://example.com/image3.jpg',
      ],
      reviews: [
        ReviewModel(
          userName: 'Maria Garcia',
          date: DateTime.now(),
          comment: 'Excelente trabajo y puntualidad.',
          rating: 5,
          imagen: 'https://example.com/reviewer1.jpg',
        ),
        ReviewModel(
          userName: 'Carlos Ruiz',
          date: DateTime.now(),
          comment: 'Muy profesional y cumplió con las expectativas.',
          rating: 4,
          imagen: 'https://example.com/reviewer2.jpg',
        ),
      ],
    );
  }
}

// Proveedor para el repositorio de AboutMe
final aboutMeRepositoryProvider = Provider((ref) => AboutMeRepository());
