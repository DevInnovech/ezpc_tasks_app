class ScheduleModel {
  final String startTime;
  final String endTime;

  ScheduleModel({
    required this.startTime,
    required this.endTime,
  });
}
