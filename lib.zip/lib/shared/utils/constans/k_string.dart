class KString {
  static const String appName = 'EZPC';
  static const String appTitle = 'EZPC Tasks';
  static const String appDeveloper = 'Artimattercode';
  static const String appVersion = '1.0.0';
  static const String cachedOnBoardingKey = 'cachedOnBoardingKey';
  static const String cacheUserResponse = 'cacheUserResponse';
  static const String getExistingUserResponseKey = 'exitingUserResponse';
  static const String cachedWebSettingKey = 'cachedWebSettingKey';
  static const String cachedProviderResponseKey = 'cachedProviderResponseKey';
}
